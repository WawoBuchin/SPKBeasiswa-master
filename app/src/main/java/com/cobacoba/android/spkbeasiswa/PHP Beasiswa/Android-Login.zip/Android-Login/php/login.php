<?php

// array for JSON response
$response = array();

// check for required fields
if(isset($_POST['username']) && isset($_POST['password'])){
	// buat koneksi
	$koneksi = mysqli_connect("localhost", "root", "", "android_w12");

	$username = $_POST['username'];
	$password = $_POST['password'];

	$sql = "SELECT * FROM users
			WHERE username = '$username' AND
				  password = '$password'";
	$result = mysqli_query($koneksi, $sql);

	if(mysqli_num_rows($result) > 0){
		$response['success'] = 1;
		echo json_encode($response);
	}else{
		$response['success'] = 0;
		$response['message'] = "Username or password incorrect.";
		echo json_encode($response);
	}
}else{
	// required field is missing
	$response['success'] = 0;
	$response['message'] = "Required field(s) is missing!";
	// echoing JSON response
	echo json_encode($response);
}