<?php // login2.php

$response = array();

// melakukan pengecekan login
// 1. apakah form login di isi lengkap
if(isset($_POST['username']) && isset($_POST['password'])){
	$username = $_POST['username'];
	$password = $_POST['password'];
	// koneksi ke db
	$koneksi = mysqli_connect("localhost", "root", "", "android_w12");

	// sql statement
	$sql = "SELECT * FROM users
			WHERE username = '$username'";

	// sql statement di jalankan
	$result = mysqli_query($koneksi, $sql);

	// cek apakah ada hasilnya..
	if($row = mysqli_fetch_array($result)){
		// cek apakah password sesuai
		if(password_verify($password, $row['password'])){
			// login berhasil
			$response['success'] = 1;
		}else{
			$response['success'] = 0;
			$response['message'] = "password salah";
		}
	}else{
		$response['success'] = 0;
		$response['message'] = "Username / password tidak sesuai.";
		// gagal login
	}
}else{
	// gagal login
	$response['success'] = 0;
	$response['message'] = "Form login tidak diisi dengan lengkap.";
}

echo json_encode($response);

//echo json_encode($response);